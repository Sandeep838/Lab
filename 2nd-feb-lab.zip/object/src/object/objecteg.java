package object;
public class objecteg {
int id;
String Name;
}
class Object{
	public static void main(String args[]) {
	objecteg obj=new objecteg();
	
	obj.id=101;
	obj.Name="sandeep";
	System.out.println(obj.id+" "+obj.Name);
	
}
}